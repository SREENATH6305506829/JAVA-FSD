package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;s

public class FacebookLogin {
	
	public static void main(String[] args) {
		
		//STEP:1 declare a path

		String path= "E:\\Java FSD Phase-5\\All Downloads\\Downloads\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//STEP:2 initialize the web driver
		
		WebDriver driver= new ChromeDriver();
		
		
		//STEP:3 give the base url
				String url="https://www.facebook.com/";
				driver.get(url);
				
				//maximize the window
				driver.manage().window().maximize();
			
				//get title of page
				System.out.println("Title:"+driver.getTitle());
				
				
				WebElement email=driver.findElement(By.id("email"));
				System.out.println(email.getAttribute("placeholder"));
				email.sendKeys("Lokesh@gmail.com");
				
				WebElement pass=driver.findElement(By.name("pass"));
				System.out.println(pass.getAttribute("placeholder"));
				pass.sendKeys("Lokesh@987");
				
				WebElement login=driver.findElement(By.name("login"));
				login.submit();

	}

}
